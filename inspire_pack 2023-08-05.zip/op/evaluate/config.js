"use strict"
module.exports = {
    prefix: null,
    room: [],
    hash: []
}
"use strict"
module.exports = function(path, r_inspire){
r_inspire('format')
return {
    fromFormat: r_inspire('fromFormat')
}
}